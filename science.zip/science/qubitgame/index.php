<?php
$nivel;
$nombre;
$mensaje=
$baseUrl="http://softitlan.com/ciencia/QubitGame";
$dir=$baseUrl."?nombre=".$nombre."&nivel=".$nivel;
if(isset($_GET['nivel'])){
	$nivel =$_GET['nivel'];
}
if(isset($_GET['nombre'])){
	$nombre = $_GET['nombre'];
}

if($nombre && $nivel){
	$mensaje =$nombre . ' logro llegar al nivel: '.$nivel.' ¿Podrás superarlo?';
	$dir=$baseUrl."?nombre=".$nombre."&nivel=".$nivel;
}else{
	$mensaje = "!Aprende sobre la computación cuántica y pon a prueba tus habilidades¡";
	$dir=$baseUrl;
}
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta property="og:url" content="<?php echo $dir ?>" />
	<meta property="og:title" content="Desafío cuántico!!!" />
	<meta property="og:description" content="<?php echo $mensaje; ?>" />
	<meta property="og:image" content="https://www.iberdrola.com/wcorp/gc/prod/es_ES/comunicacion/computacion_cuantica_mult_1_res/Computacion_Cuantica_746x419.jpg" />
    <title>Qubit Game | SoftitlanMX</title>
    <link rel="shortcut icon" href="TemplateData/favicon.ico">
    <link rel="stylesheet" href="TemplateData/style.css">
    <script src="TemplateData/UnityProgress.js"></script>
    <script src="Build/UnityLoader.js"></script>
    <script>
      var gameInstance = UnityLoader.instantiate("gameContainer", "Build/Demo.json", {onProgress: UnityProgress});
    </script>
  </head>
  <body>
	<div>
		<h1 style="text-align: center">¡Pon a prueba tu conocimiento en el mundo de la computación cuántica!</h1>
    </div>
	<div class="webgl-content">
      <div id="gameContainer" style="width: 992px; height: 558px"></div>
      <div class="footer">
	<div class="fb-share-button"
	data-href="<?php echo $dir;?>"
	data-layout="button" data-size="small">
		<a target="_blank
			href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $dir; ?>&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">
				Compartir
		</a>
	</div>
        <div class="fullscreen" onclick="gameInstance.SetFullscreen(1)"></div>
        <div class="title">Pantalla completa</div>
    </div>
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous"
	src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v8.0" nonce="xkGzhXJs">
	</script>
  </body>
</html>
